from django.conf.urls import url, include
from django.contrib import admin
from core import views
from curriculo.views import cadastro_aluno, listarCursos , inserirDisciplina
from restrito.views import inserirAtividade, listarAtividade, alterarAtividade, deletarAtividade
from contas.views import listarMensagem, inserirMensagem, alterarMensagem, deletarMensagem
from django.urls import path, include
from curriculo import urls as curriculo_urls
from restrito import urls as restrito_urls
from contas import urls as contas_urls




urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name ='index'),
    path('cadastro-disciplina/', views.cadastro_disciplina, name = "cadastro_disciplina"),
    path('cursos/', views.cursos, name="cursos"),
    path('cadastro-aluno/', cadastro_aluno, name ="cadastro_aluno"),
    path('cursos/grade-ads/', views.grade_ads, name="grade_ads"),
    path('cursos/grade-redes/',views.grade_redes, name="grade_redes"),
    path('cursos/grade-bd/', views.grade_bd, name = "grade_bd"),
    path('cursos/desc-ads/', views.desc_ads, name = "cursos/desc_ads"),
    path('cursos/desc-bd/', views.desc_bd, name= "cursos/desc_bd"),
    path('cursos/desc-redes/', views.desc_redes, name = "cursos/desc_redes"),
    path('cursos/desc-bd-lp/', views.desc_bd_lp, name = "cursos/desc_bd_lp"),
    path('cursos/desc-bd-fbd/', views.desc_bd_fbd, name ="cursos/desc_bd_fbd"),
    path('cursos/desc-bd-dba/', views.desc_bd_dba, name ="desc_bd_dba"),
    path('cursos/desc-ads/grade-ads/', views.grade_ads, name="grade_ads"),
    path('cursos/desc-ads/grade-bd/', views.grade_bd, name="grade_bd"),
    path('cursos/desc-ads/grade-redes/', views.grade_redes, name="grade_redes"),
    path('login/', views.login, name = "login"),
    path('tabela-aluno/', views.tabela_aluno, name = "tabela_aluno"),  
    path('cadastro-disciplina', views.cadastro_disciplina, name="cadastro_disciplina"),
    path('curriculo/', include(curriculo_urls)),
    path('contas/', include(contas_urls)),
    path('restrito/', include(restrito_urls)),
    # path('core/', include(core_urls)), 
]
from django.shortcuts import render, redirect
from .models.atividade import Atividade
from contas.models.professor import Professor
# Create your views here.

def listarAtividade(request):
    contexto={
        "atividades": Atividade.objects.all()
    }
    return render(request,'listarAtividade.html', contexto)


def inserirAtividade(request):
    contexto={"professores": Professor.objects.all()}
    if request.POST:
        idprofessor=Professor.objects.get(idprofessor=request.POST.get("professor"))
        Atividade.objects.create(
            titulo=request.POST.get("Titulo"),
            descricao=request.POST.get("Descricao"),
            conteudo=request.POST.get("Conteudo"),
            tipo=request.POST.get("Tipo"),
            extra=request.POST.get("Extra"),
            idprofessor=idprofessor
        )
        return redirect('listar-atividade')
    else:
        return render(request, "novaAtividade.html", contexto)


def alterarAtividade(request,idatividade):
    contexto = {
        "atividades": Atividade.objects.all(),
        "professores": Professor.objects.all()
    }

    if request.POST:
        idprofessor=Professor.objects.get(idprofessor=request.POST.get("professor"))
        atividade=Atividade.objects.get(idatividade=idatividade)

        atividade.titulo=request.POST.get("Titulo")
        atividade.descricao=request.POST.get("Descricao")
        atividade.conteudo=request.POST.get("Conteudo")
        atividade.tipo=request.POST.get("Tipo")
        atividade.extra=request.POST.get("Extra")
        
        atividade.save()
        return redirect('listar-atividade')
    else:
        return render(request,"novaAtividade.html", contexto)


def deletarAtividade(request, idatividade):
    atividade = Atividade.objects.get(idatividade=idatividade)
    atividade.delete()
    return redirect('listar-atividade')


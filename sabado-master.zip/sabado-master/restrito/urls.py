from django.contrib import admin
from django.urls import path, include
from django.conf.urls import url, include
from restrito.views import *

urlpatterns = [
    path('listar-atividade/', listarAtividade, name="listar-atividade"),
    path('nova-atividade/', inserirAtividade, name="nova-atividade"),
    path('alteraratividade/<int:idatividade>/', alterarAtividade, name="alteraratividade"),
    path('deletaratividade/<int:idatividade>/', deletarAtividade, name="deletaratividade"),
]
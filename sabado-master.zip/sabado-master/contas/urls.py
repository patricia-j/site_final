from django.contrib import admin
from django.urls import path, include
from django.conf.urls import url, include
from contas.views import *

urlpatterns = [
    path('listar-mensagem/', listarMensagem, name="listar-mensagem"),
    path('nova-mensagem/', inserirMensagem, name="nova-mensagem"),
    path('alterarmensagem/<int:idmensagem>', alterarMensagem, name="alterarmensagem"),
    path('deletarmensagem/<int:idmensagem>', deletarMensagem, name="deletarmensagem")
]
    
